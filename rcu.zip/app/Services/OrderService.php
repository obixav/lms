<?php

namespace App\Services;
use App\Facades\Cart;

use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderLine;
use App\Models\PaystackTransaction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Ramsey\Uuid\Uuid;
use Unicodeveloper\Paystack\Facades\Paystack;

class OrderService
{
    public function saveOrders($request)
    {
        if(Auth::guard('customer')->user())
        {
            $customer_id=Auth::guard('customer')->id();
        }else{
           $customer= Customer::firstOrCreate(['email'=>$request->email,'name'=>$request->first_name.' '.$request->last_name,'phone'=>$request->phone]);
            $customer_id=$customer->id;
        }
        $total=Cart::total()+Cart::total_discount();
        $tracking_id=Str::ulid();
        $tax=((company_info()->tax_rate/100)*Cart::total());
        $payable=Cart::total()+$tax;
        $ref=Paystack::genTranxRef();
        $order=Order::create(['customer_id'=>$customer_id,'tracking_id'=>$tracking_id,
            'status'=>0,'payment_status'=>0,'payment_channel'=>'online','amount'=>$total,
            'tax'=>$tax,'total_after_discount'=>Cart::total(),'total_payable'=> $payable,
            'payment_ref'=>$ref]);
        $content= Cart::content();

        foreach ($content as $id => $item)
        {
            $discount= isset($item->get('options')['discount'])?$item->get('options')['discount']*$item->get('quantity'):0;
            $order_line=OrderLine::create(['order_id'=>$order->id,
                'product_id'=>$id,'quantity'=>$item->get('quantity'),'unit_price'=>$item->get('price')+$discount,
                'discount'=>$discount*$item->get('quantity'),'total'=>$item->get('price')*$item->get('quantity')
                ]);

        }

        $data = array(
            "amount" => $payable * 100,
            "reference" => $ref,
            "email" => $order->customer->email,
            "currency" => "NGN",
            "orderID" => $order->id,
        );
        $pt=PaystackTransaction::create(['order_id'=>$order->id,'payment_ref'=>$ref,
            'payload'=>$data]);

        try{
            return Paystack::getAuthorizationUrl($data)->redirectNow();
        }catch(\Exception $e) {
            return back()->with(['msg'=>'The paystack token has expired. Please refresh the page and try again.', 'type'=>'error']);
        }
    }





}
