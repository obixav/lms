<?php

namespace App\Http\Controllers;

use App\Http\Requests\SaveSettingRequest;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Tag;
use App\Services\ClientService;
use App\Services\TeamMemberService;
use App\Services\ProductService;
use App\Services\ProjectService;
use App\Services\ServiceService;
use App\Services\SettingService;
use Illuminate\Http\Request;


class AdminController extends Controller
{
    function dashboard()
    {
        return view('admin.dashboard');
    }
    function settings(Request $request, SettingService $settingService)
    {
        // return view('admin.settings.index');
        return $settingService->viewSetting();
    }

    function saveSettings(SaveSettingRequest $saveSettingRequest, SettingService $settingService)
    {
       return $settingService->saveSetting($saveSettingRequest);
    }

    function products(Request $request, ProductService $productService) {
        return $productService->viewProducts($request);

    }

    public function editProduct(Request $request,ProductService $productService,$product_id)
    {
        return $productService->editProduct($product_id);
    }
    function productCategories(Request $request, ProductService $productService) {
        return $productService->viewProductcategories();

    }
    function saveProductCategories(Request $request, ProductService $productService) {
        return $productService->saveProductCategory($request);

    }
    function saveProducts(Request $request, ProductService $productService) {
        return $productService->saveProduct($request);

    }
    function deleteProduct(Request $request, ProductService $productService,$product_id) {
        return $productService->deleteProduct($product_id);

    }
    function updateProducts(Request $request, ProductService $productService) {
        return $productService->updateProduct($request);

    }

    function projectCategories(Request $request, ProjectService $projectService) {
        return $projectService->viewProjectcategories();

    }
    function saveProjectCategories(Request $request, ProjectService $projectService) {
        return $projectService->saveProjectCategory($request);

    }
    function projects(Request $request, ProjectService $projectService) {
        return $projectService->viewProjects($request);

    }
    public function editProject(Request $request, ProjectService $projectService, $project_id)
    {
        return $projectService->editProject($project_id);
    }
    function saveProjects(Request $request, ProjectService $projectService) {
        return $projectService->saveProject($request);

    }
    function deleteProject(Request $request, ProjectService $projectService, $project_id) {
        return $projectService->deleteProject($project_id);

    }
    function updateProjects(Request $request, ProjectService $projectService) {
        return $projectService->updateProject($request);

    }
    //

    function services(Request $request, ServiceService $serviceService) {
        return $serviceService->viewServices($request);

    }
    public function editService(Request $request, ServiceService $serviceService, $service_id)
    {
        return $serviceService->editService($service_id);
    }
    function saveServices(Request $request, ServiceService $serviceService) {
        return $serviceService->saveService($request);

    }
    function deleteService(Request $request, ServiceService $serviceService, $service_id) {
        return $serviceService->deleteService($service_id);

    }
    function updateServices(Request $request, ServiceService $serviceService) {
        return $serviceService->updateService($request);

    }
//
    function clients(Request $request, ClientService $clientService) {
        return $clientService->viewClients($request);

    }
    public function editClient(Request $request, ClientService $clientService, $client_id)
    {
        return $clientService->editClient($client_id);
    }
    function saveClients(Request $request, ClientService $clientService) {
        return $clientService->saveClient($request);

    }
    function deleteClient(Request $request, ClientService $clientService, $client_id) {
        return $clientService->deleteClient($client_id);

    }
    function updateClients(Request $request, ClientService $clientService) {
        return $clientService->updateClient($request);

    }
    function designRequests(Request $request, ProjectService $projectService) {
        return $projectService->viewDesignRequests($request);

    }
    function saveDesignRequests(Request $request, ProjectService $projectService) {
        return $projectService->saveDesignRequestResponse($request);

    }
    function viewDesignRequest(Request $request, ProjectService $projectService,$design_request_id) {
        return $projectService->viewDesignRequest($design_request_id);

    }
    function customers(Request $request) {
        $customers=Customer::where('id','!=',0);
        if($request->filled('q'))
        {
            $q = $request->input('q');

            $customers->where(function ($query) use ($q) {
                $query->where('name', 'like', '%' . $q . '%')
                    ->where('email', 'like', '%' . $q . '%')
                    ->orWhere('phone', $q);
            });
        }
        $customers=$customers->get();
        return view('admin.customers.index',compact('customers'));

    }
    //
    function team_members(Request $request, TeamMemberService $TeamMemberService) {
        return $TeamMemberService->viewTeamMembers($request);

    }
    public function editTeamMember(Request $request, TeamMemberService $TeamMemberService, $team_member_id)
    {
        return $TeamMemberService->editTeamMember($team_member_id);
    }
    function saveTeamMembers(Request $request, TeamMemberService $TeamMemberService) {
        return $TeamMemberService->saveTeamMember($request);

    }
    function deleteTeamMember(Request $request, TeamMemberService $TeamMemberService, $team_member_id) {
        return $TeamMemberService->deleteTeamMember($team_member_id);

    }
    function updateTeamMembers(Request $request, TeamMemberService $TeamMemberService) {
        return $TeamMemberService->updateTeamMember($request);

    }

    function tagSearch(Request $request)
    {

        if($request->q==""){
            return "";
        }
       else{
        $name=Tag::where('name','LIKE','%'.$request->q.'%')
                        ->select('name as id','name as text')
                        ->get();
            }


        return $name;
    }
}
