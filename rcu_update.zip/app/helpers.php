<?php
function truncate(string $text, int $length = 20): string {
    if (strlen($text) <= $length) {
        return $text;
    }
    $text = substr($text, 0, $length);
    $text = substr($text, 0, strrpos($text, " "));
    $text .= "...";
    return $text;
}

function company_info()
{
    return \App\Models\Setting::first();
}

function projects()
{
    return \App\Models\Project::all();
}
